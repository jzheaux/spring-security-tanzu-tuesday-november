package com.example.authz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthzApplicationTests {

	@Test
	void contextLoads() {
	}

}
