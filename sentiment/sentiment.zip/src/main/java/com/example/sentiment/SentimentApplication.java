package com.example.sentiment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SentimentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SentimentApplication.class, args);
	}

}
